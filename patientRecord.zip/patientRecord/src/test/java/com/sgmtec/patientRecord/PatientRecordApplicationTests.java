package com.sgmtec.patientRecord;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientRecordApplicationTests {

	@Test
	void contextLoads() {
	}

}
